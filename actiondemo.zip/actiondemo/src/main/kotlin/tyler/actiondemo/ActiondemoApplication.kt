package tyler.actiondemo

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class ActiondemoApplication

fun main(args: Array<String>) {
	runApplication<ActiondemoApplication>(*args)
}
