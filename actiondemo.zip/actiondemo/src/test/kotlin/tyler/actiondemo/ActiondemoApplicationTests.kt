package tyler.actiondemo

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class ActiondemoApplicationTests {

	@Test
	fun contextLoads() {
	}

}
